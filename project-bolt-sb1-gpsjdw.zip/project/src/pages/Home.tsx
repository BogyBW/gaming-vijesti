import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, limit, getDocs, where } from 'firebase/firestore';
import { useSearchParams } from 'react-router-dom';
import { db } from '../lib/firebase';
import ArticleCard from '../components/ArticleCard';

export default function Home() {
  const [articles, setArticles] = useState([]);
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('q');
  const tab = searchParams.get('tab') || 'recent';

  useEffect(() => {
    const fetchArticles = async () => {
      let q;
      
      if (searchQuery) {
        q = query(
          collection(db, 'articles'),
          where('title', '>=', searchQuery),
          where('title', '<=', searchQuery + '\uf8ff'),
          limit(10)
        );
      } else {
        switch (tab) {
          case 'popular':
            q = query(collection(db, 'articles'), orderBy('likes', 'desc'), limit(10));
            break;
          case 'recent':
            q = query(collection(db, 'articles'), orderBy('createdAt', 'desc'), limit(10));
            break;
          default:
            q = query(collection(db, 'articles'), orderBy('createdAt', 'desc'), limit(10));
        }
      }

      const querySnapshot = await getDocs(q);
      const articlesData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setArticles(articlesData);
    };

    fetchArticles();
  }, [searchQuery, tab]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-white">
            {searchQuery ? `Rezultati pretrage: ${searchQuery}` : 'Najnovije Vijesti'}
          </h1>
          {!searchQuery && (
            <div className="flex space-x-4">
              <a
                href="/?tab=recent"
                className={`px-4 py-2 rounded-full ${
                  tab === 'recent'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                Najnovije
              </a>
              <a
                href="/?tab=popular"
                className={`px-4 py-2 rounded-full ${
                  tab === 'popular'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                Popularno
              </a>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {articles.map((article: any) => (
            <ArticleCard key={article.id} article={article} />
          ))}
          {articles.length === 0 && (
            <div className="col-span-3 text-center text-gray-400 py-12">
              {searchQuery ? 'Nema pronađenih članaka' : 'Nema dostupnih članaka'}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}