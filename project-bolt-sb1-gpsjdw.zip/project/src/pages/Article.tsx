import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, updateDoc, increment, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { Heart, MessageSquare, Trash2 } from 'lucide-react';
import Comments from '../components/Comments';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';

export default function Article() {
  const { id } = useParams();
  const { currentUser, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [article, setArticle] = useState<any>(null);
  const [hasLiked, setHasLiked] = useState(false);
  const [viewLogged, setViewLogged] = useState(false);

  useEffect(() => {
    const fetchArticle = async () => {
      if (!id) return;

      const docRef = doc(db, 'articles', id);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        setArticle({ id: docSnap.id, ...docSnap.data() });
        
        if (!viewLogged) {
          await updateDoc(docRef, {
            views: increment(1)
          });
          setViewLogged(true);
        }

        if (currentUser) {
          const likeRef = doc(db, `articles/${id}/likes/${currentUser.uid}`);
          const likeDoc = await getDoc(likeRef);
          setHasLiked(likeDoc.exists());
        }
      }
    };

    fetchArticle();
  }, [id, currentUser, viewLogged]);

  const handleLike = async () => {
    if (!currentUser || !id) return;

    const likeRef = doc(db, `articles/${id}/likes/${currentUser.uid}`);
    const likeDoc = await getDoc(likeRef);

    if (!likeDoc.exists()) {
      await setDoc(likeRef, { timestamp: new Date().toISOString() });
      await updateDoc(doc(db, 'articles', id), {
        likes: increment(1)
      });
      setHasLiked(true);
    } else {
      await deleteDoc(likeRef);
      await updateDoc(doc(db, 'articles', id), {
        likes: increment(-1)
      });
      setHasLiked(false);
    }
  };

  const handleDelete = async () => {
    if (!isAdmin || !id) return;

    const confirm = window.confirm('Da li ste sigurni da želite obrisati ovaj članak?');
    if (!confirm) return;

    try {
      await deleteDoc(doc(db, 'articles', id));
      toast.success('Članak je uspješno obrisan');
      navigate('/');
    } catch (error) {
      toast.error('Greška pri brisanju članka');
      console.error('Error deleting article:', error);
    }
  };

  if (!article) return null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black py-8">
      <article className="max-w-4xl mx-auto px-4">
        <img
          src={article.imageUrl}
          alt={article.title}
          className="w-full h-96 object-cover rounded-xl mb-8"
        />

        <div className="flex justify-between items-start mb-4">
          <h1 className="text-4xl font-bold text-white">{article.title}</h1>
          {isAdmin && (
            <button
              onClick={handleDelete}
              className="text-red-500 hover:text-red-600 p-2"
              title="Obriši članak"
            >
              <Trash2 className="h-6 w-6" />
            </button>
          )}
        </div>

        <div className="flex items-center justify-between text-gray-400 mb-8">
          <div className="flex items-center space-x-4">
            <span>Autor: {article.author}</span>
            <span>{formatDistanceToNow(new Date(article.createdAt))} ago</span>
          </div>
          <div className="flex items-center space-x-6">
            <button
              onClick={handleLike}
              className={`flex items-center space-x-2 ${
                hasLiked ? 'text-red-500' : 'text-gray-400 hover:text-red-500'
              }`}
              disabled={!currentUser}
            >
              <Heart className={`h-6 w-6 ${hasLiked ? 'fill-current' : ''}`} />
              <span>{article.likes}</span>
            </button>
          </div>
        </div>

        <div
          className="prose prose-invert max-w-none mb-8"
          dangerouslySetInnerHTML={{ __html: article.content }}
        />

        {article.footer && (
          <div className="border-t border-gray-800 pt-6 mt-8 text-gray-400">
            {article.footer}
          </div>
        )}

        <Comments articleId={id} />
      </article>
    </div>
  );
}