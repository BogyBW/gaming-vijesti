import React from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { Heart, Eye } from 'lucide-react';

interface ArticleCardProps {
  article: {
    id: string;
    title: string;
    imageUrl: string;
    excerpt: string;
    createdAt: string;
    likes: number;
    views: number;
    author: string;
  };
}

export default function ArticleCard({ article }: ArticleCardProps) {
  return (
    <div className="bg-gradient-to-br from-gray-900 to-black rounded-lg overflow-hidden shadow-xl transform transition-all hover:scale-105">
      <Link to={`/article/${article.id}`}>
        <img
          src={article.imageUrl}
          alt={article.title}
          className="w-full h-48 object-cover"
        />
        <div className="p-6">
          <h2 className="text-xl font-bold text-white mb-2">{article.title}</h2>
          <p className="text-gray-400 mb-4">{article.excerpt}</p>
          
          <div className="flex items-center justify-between text-sm text-gray-400">
            <div className="flex items-center space-x-4">
              <span className="flex items-center">
                <Heart className="h-4 w-4 mr-1 text-red-500" />
                {article.likes}
              </span>
              <span className="flex items-center">
                <Eye className="h-4 w-4 mr-1 text-blue-500" />
                {article.views}
              </span>
            </div>
            <div className="flex flex-col items-end">
              <span className="text-blue-400">{article.author}</span>
              <span>{formatDistanceToNow(new Date(article.createdAt))} ago</span>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}