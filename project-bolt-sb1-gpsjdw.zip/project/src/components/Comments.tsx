import React, { useState, useEffect } from 'react';
import { collection, addDoc, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { formatDistanceToNow } from 'date-fns';

export default function Comments({ articleId }: { articleId: string }) {
  const { currentUser } = useAuth();
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');

  useEffect(() => {
    const q = query(
      collection(db, `articles/${articleId}/comments`),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const commentsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setComments(commentsData);
    });

    return () => unsubscribe();
  }, [articleId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    await addDoc(collection(db, `articles/${articleId}/comments`), {
      content: newComment,
      author: currentUser.email,
      createdAt: new Date().toISOString()
    });

    setNewComment('');
  };

  return (
    <div className="mt-12">
      <h2 className="text-2xl font-bold text-white mb-6">Comments</h2>

      {currentUser ? (
        <form onSubmit={handleSubmit} className="mb-8">
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            className="w-full px-4 py-2 rounded-lg bg-gray-800 text-white border border-gray-700 focus:outline-none focus:border-blue-500"
            placeholder="Write a comment..."
            rows={3}
            required
          />
          <button
            type="submit"
            className="mt-2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg"
          >
            Post Comment
          </button>
        </form>
      ) : (
        <p className="text-gray-400 mb-8">Please sign in to comment.</p>
      )}

      <div className="space-y-6">
        {comments.map((comment: any) => (
          <div
            key={comment.id}
            className="bg-gray-800 rounded-lg p-4"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-blue-400">{comment.author}</span>
              <span className="text-gray-400 text-sm">
                {formatDistanceToNow(new Date(comment.createdAt))} ago
              </span>
            </div>
            <p className="text-white">{comment.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}