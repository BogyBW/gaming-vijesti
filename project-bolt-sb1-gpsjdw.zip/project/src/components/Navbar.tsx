import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Search, LogIn, LogOut, PenSquare, User } from 'lucide-react';

export default function Navbar() {
  const { currentUser, isAdmin, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <nav className="bg-gradient-to-r from-blue-900 to-black text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="text-xl font-bold">
              Gaming Vijesti
            </Link>
            <div className="ml-10 flex items-baseline space-x-4">
              <Link to="/" className="hover:text-blue-300 px-3 py-2">Početna</Link>
              <Link to="/?tab=popular" className="hover:text-blue-300 px-3 py-2">Popularno</Link>
              <Link to="/?tab=recent" className="hover:text-blue-300 px-3 py-2">Najnovije</Link>
            </div>
          </div>

          <div className="flex items-center">
            <form onSubmit={handleSearch} className="mr-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Pretraži članke..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-gray-800 text-white rounded-full pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </form>

            {currentUser ? (
              <div className="flex items-center space-x-4">
                {isAdmin && (
                  <Link to="/create-article" className="hover:text-blue-300">
                    <PenSquare className="h-5 w-5" />
                  </Link>
                )}
                <Link to="/profile" className="hover:text-blue-300">
                  <User className="h-5 w-5" />
                </Link>
                <button
                  onClick={() => logout()}
                  className="hover:text-blue-300"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            ) : (
              <Link
                to="/login"
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-full"
              >
                <LogIn className="h-5 w-5" />
                <span>Prijavi se</span>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}