import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyDGiugL3gqpw2qNm6U4IwaM_RKYOAbZsYU",
  authDomain: "gaming-vijestime.firebaseapp.com",
  projectId: "gaming-vijestime",
  storageBucket: "gaming-vijestime.firebasestorage.app",
  messagingSenderId: "1060220807471",
  appId: "1:1060220807471:web:0da246a0648a6ccb2dd9da",
  measurementId: "G-73ED5K55W6"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);